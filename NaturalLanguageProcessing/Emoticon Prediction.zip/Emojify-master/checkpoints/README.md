
path to checkpoints

opps,it seems that I can not upload files more than 25MB,so I will upload it to goodle driver,but suggest you train it  yourself,
only take a few minites on GPU.
